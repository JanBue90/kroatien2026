v18: Kegeltour-Fotospiel mit 18 eingebauten Bildern, zufälliger Reihenfolge, Ort +2, Jahr +1, Buzzer/10s, Bilder auf TV und Spieler-Handys. Für GitHub alle Dateien inkl. Ordner tourphotos hochladen.
