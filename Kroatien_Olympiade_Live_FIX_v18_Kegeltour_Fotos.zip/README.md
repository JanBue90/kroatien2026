v17 – Promi-Mix Spiel

Neuer Spielleiter-Modus „Promi-Mix“ mit 12 Runden.
Je Runde hinterlegbar:
- Foto des Kegelbruders
- Foto des Promis
- fertiges KI-Morph-Bild
- beide Namen

Spiel:
- TV zeigt zunächst das KI-Morph hinter einem 4x4-Puzzle (16 Felder).
- Jan kann einzelne Teile aufdecken oder automatisch alle 1,2 Sekunden weiter aufdecken.
- Der bestehende Buzzer läuft separat weiter.
- Bei RICHTIG wird die Lösung auf TV und Spielleiter gezeigt:
  Kegelbruder | KI-Mix | Promi.
- Vorherige/nächste Runde und Reset vorhanden.
- Konfiguration wird lokal im Browser des Spielleiters gespeichert.

Wichtig: Große Originalfotos können den Browser-Speicher sprengen. Für die fertige Reiseversion ist es besser, die 36 Bilder direkt als Dateien ins GitHub-Repository zu legen. Diese Version ist zum Einrichten/Testen per Browser geeignet.

GitHub: nur index.html ersetzen.
